export class User {
    username: string | undefined;
    password: string | undefined;
    email: string | undefined;
    bio: string | undefined;
}